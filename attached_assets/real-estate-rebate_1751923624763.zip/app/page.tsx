"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { DollarSign, Phone, Mail, MapPin, CheckCircle, Star, Shield, Clock, ArrowDown } from "lucide-react"

export default function RealEstateRebate() {
  const [purchasePrice, setPurchasePrice] = useState([500000])
  const [rebatePercentage] = useState(2) // Up to 2% rebate
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    priceRange: "",
  })

  const calculateRebate = (price: number) => {
    return (price * rebatePercentage) / 100
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
    alert("Thank you! We'll contact you soon to discuss your rebate.")
  }

  const currentRebate = calculateRebate(purchasePrice[0])

  return (
    <div className="min-h-screen bg-gradient-to-br from-trust-gray-50 to-trust-navy-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-trust-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-trust-navy-800 px-3 py-2 rounded-lg">
              <img src="/images/homesmart-logo.png" alt="HomeSmart Logo" className="h-6 w-auto" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-trust-navy-900">WhyRebate</span>
              <span className="text-xs text-trust-gray-600 -mt-1">We Hear You</span>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <div className="text-sm text-trust-navy-700 font-medium">
              Your Savings:{" "}
              <span className="text-trust-green-700 font-bold">Up to {formatCurrency(currentRebate)}</span>
            </div>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-trust-green-700 hover:bg-trust-green-800 text-white font-semibold pulse"
            >
              Get My Rebate
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Calculator Section */}
      <section id="calculator" className="py-12 px-4 bg-white">
        <div className="container mx-auto">
          {/* Social Proof Bar */}
          <div className="text-center mb-8">
            <Badge className="mb-4 bg-trust-green-100 text-trust-green-800 hover:bg-trust-green-100 border-trust-green-200 text-base px-4 py-2">
              <Shield className="w-4 h-4 mr-2" />
              Save Up to 2% on Your Home Purchase
            </Badge>
          </div>

          <div className="max-w-5xl mx-auto">
            <Card className="shadow-2xl border-0 bg-gradient-to-br from-trust-navy-50 to-trust-gray-50 overflow-hidden">
              <CardHeader className="text-center pb-6 bg-gradient-to-r from-trust-navy-700 to-trust-navy-800 text-white">
                <CardTitle className="text-3xl font-bold">Calculate Your Savings</CardTitle>
                <CardDescription className="text-lg text-trust-navy-100">
                  See your rebate estimate in real-time
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid lg:grid-cols-2 gap-8 items-center">
                  {/* Calculator Controls */}
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <Label className="text-xl font-semibold text-trust-navy-800">
                        Home Purchase Price: {formatCurrency(purchasePrice[0])}
                      </Label>
                      <Slider
                        value={purchasePrice}
                        onValueChange={setPurchasePrice}
                        max={2000000}
                        min={100000}
                        step={25000}
                        className="w-full h-3"
                      />
                      <div className="flex justify-between text-sm text-trust-gray-500">
                        <span>$100,000</span>
                        <span>$2,000,000</span>
                      </div>
                    </div>

                    {/* Urgency Element */}
                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-5 h-5 text-yellow-600" />
                        <p className="text-sm font-medium text-yellow-800">
                          <strong>Limited Time:</strong> Lock in your rebate rate today
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Results Display */}
                  <div className="space-y-4">
                    <div className="text-center p-8 bg-gradient-to-br from-trust-green-50 to-trust-green-100 rounded-2xl border-2 border-trust-green-200">
                      <DollarSign className="h-16 w-16 text-trust-green-700 mx-auto mb-4" />
                      <h3 className="text-2xl font-semibold text-trust-navy-800 mb-2">Your Rebate</h3>
                      <p className="text-5xl font-bold text-trust-green-700 mb-2">
                        Up to {formatCurrency(currentRebate)}
                      </p>
                      <p className="text-lg text-trust-gray-600">Back at closing</p>

                      {/* Comparison */}
                      <div className="mt-6 pt-4 border-t border-trust-green-200">
                        <p className="text-sm text-trust-gray-600 mb-2">vs. Traditional Agent:</p>
                        <p className="text-lg font-semibold text-trust-navy-800">
                          You could save:{" "}
                          <span className="text-trust-green-700">Up to {formatCurrency(currentRebate)}</span>
                        </p>
                      </div>
                    </div>

                    {/* CTA Button */}
                    <Button
                      onClick={() => setShowForm(true)}
                      className="w-full bg-trust-green-700 hover:bg-trust-green-800 text-white text-xl py-4 font-bold shadow-lg hover:shadow-xl transition-all duration-200"
                    >
                      Start Saving Today
                      <ArrowDown className="ml-2 w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Immediate Lead Capture Form - Conditional */}
      {showForm && (
        <section className="py-8 px-4 bg-trust-green-50 border-t-4 border-trust-green-500">
          <div className="container mx-auto">
            <Card className="max-w-lg mx-auto shadow-xl">
              <CardHeader className="bg-trust-navy-700 text-white rounded-t-lg">
                <CardTitle className="text-2xl text-center">Get Your Rebate Quote</CardTitle>
                <CardDescription className="text-center text-trust-navy-100">
                  Get started in under 60 seconds
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-trust-navy-800 font-medium">
                      Full Name *
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Enter your full name"
                      className="border-trust-gray-300 focus:border-trust-navy-500 mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-trust-navy-800 font-medium">
                      Email Address *
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="Enter your email"
                      className="border-trust-gray-300 focus:border-trust-navy-500 mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-trust-navy-800 font-medium">
                      Phone Number *
                    </Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="Enter your phone number"
                      className="border-trust-gray-300 focus:border-trust-navy-500 mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="priceRange" className="text-trust-navy-800 font-medium">
                      Target Price Range
                    </Label>
                    <Input
                      id="priceRange"
                      name="priceRange"
                      value={formData.priceRange}
                      onChange={handleInputChange}
                      placeholder="e.g., $400,000 - $600,000"
                      className="border-trust-gray-300 focus:border-trust-navy-500 mt-1"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-trust-green-700 hover:bg-trust-green-800 text-lg py-3 font-semibold mt-6"
                  >
                    Get My Rebate Quote
                  </Button>

                  <p className="text-xs text-center text-trust-gray-500 mt-2">
                    🔒 Your information is secure and will never be shared
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Trust Indicators */}
      <section className="py-8 px-4 bg-white border-t border-trust-gray-200">
        <div className="container mx-auto">
          <div className="flex justify-center items-center space-x-12 opacity-60">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-trust-navy-600" />
              <span className="text-sm font-medium text-trust-navy-700">Licensed & Insured</span>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500" />
              <span className="text-sm font-medium text-trust-navy-700">4.9/5 Rating</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-trust-green-600" />
              <span className="text-sm font-medium text-trust-navy-700">No Hidden Fees</span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 px-4 bg-trust-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-trust-navy-900 mb-4">How Our Rebate Program Works</h2>
            <p className="text-xl text-trust-gray-700">Simple, transparent, and designed to save you money</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="bg-trust-navy-700 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold text-trust-navy-900 mb-4">Contact Us</h3>
              <p className="text-trust-gray-700">
                Reach out to our team and let us know you're interested in buying a home with our rebate program.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-trust-navy-700 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold text-trust-navy-900 mb-4">Find Your Home</h3>
              <p className="text-trust-gray-700">
                Work with our experienced agents to find and purchase your perfect home through our network.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-trust-navy-700 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold text-trust-navy-900 mb-4">Get Your Rebate</h3>
              <p className="text-trust-gray-700">
                Receive up to 2% of your purchase price back as a rebate after closing on your new home.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* We Hear You Section */}
      <section className="py-12 px-4 bg-trust-navy-800 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">We Hear You</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div>
              <p className="text-lg opacity-90">"Why should I pay full commission?"</p>
            </div>
            <div>
              <p className="text-lg opacity-90">"Can't I save money on this purchase?"</p>
            </div>
            <div>
              <p className="text-lg opacity-90">"There has to be a better way."</p>
            </div>
          </div>
          <p className="text-xl mt-8 font-semibold">That's exactly why we created WhyRebate.</p>
        </div>
      </section>

      {/* What's In It For Us Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-trust-navy-900 mb-8">What's In It For Us?</h2>

            <div className="text-left space-y-6 text-lg text-trust-gray-700 leading-relaxed mb-12">
              <p className="text-xl font-semibold text-trust-navy-800">The traditional real estate process is dead.</p>

              <p>
                Most Realtors spend a serious amount of time and money trying to work with buyers and sellers who aren't
                serious. Ultimately, the cost of their time is passed on via high commissions to clients who are
                serious.
              </p>

              <p>We think that's unfair, and believe serious clients should be rewarded.</p>

              <p>
                Our program is designed to attract serious & savvy folks on all sides of a real estate transaction,
                allowing agents to save time and pass the cost-savings onto you.
              </p>

              <div className="bg-trust-green-50 border-l-4 border-trust-green-500 p-6 my-8">
                <p className="text-xl font-semibold text-trust-navy-900 mb-4">Are you serious & savvy?</p>
                <p className="text-lg">Work with our associates on your next purchase and receive up to a 2% rebate.</p>
              </div>
            </div>

            {/* Second CTA */}
            <Button
              onClick={() => setShowForm(true)}
              className="bg-trust-green-700 hover:bg-trust-green-800 text-white text-xl py-4 px-8 font-bold shadow-lg"
            >
              Get My Better Deal
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-trust-navy-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-4 mb-4">
                <img src="/images/homesmart-logo.png" alt="HomeSmart Logo" className="h-8 w-auto opacity-90" />
                <div className="flex flex-col">
                  <span className="text-xl font-bold">WhyRebate</span>
                  <span className="text-xs text-trust-gray-400">We Hear You</span>
                </div>
              </div>
              <p className="text-trust-gray-300">
                We hear you want to save money on your home purchase. That's why we created our commission rebate
                program.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-trust-gray-300">
                <li>Home Buying</li>
                <li>Commission Rebates</li>
                <li>Market Analysis</li>
                <li>Closing Support</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-trust-gray-300">
                <li>About Us</li>
                <li>How It Works</li>
                <li>Testimonials</li>
                <li>FAQ</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="space-y-2 text-trust-gray-300">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>(555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>info@whyrebate.com</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>123 Main St, City, State</span>
                </div>
              </div>
            </div>
          </div>

          {/* Disclaimer Section */}
          <div className="border-t border-trust-navy-800 mt-8 pt-8">
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-trust-gray-300 mb-3">Important Rebate Disclosure:</h4>
              <p className="text-xs text-trust-gray-400 leading-relaxed">
                The rebate figures presented on this website are based on a seller paid buyer broker compensation of
                3-4% of the sales price. If the seller paid buyer broker compensation is less than 3.5% of the sales
                price, your rebate will be less than 2%. The minimum buyer broker compensation amount for the agents
                participating in this program is 1.5% or $4,500 whichever is higher. If your purchase price is under
                $300,000 or the seller pays less than a 3.5% buyer broker commission, your rebate will be less than 2%.
                If the seller does not pay a buyer broker commission, the buyer will fulfill the minimum buyer broker
                compensation amounts of $4,500 or 1.5% of the sales price, whichever is higher. Depending upon your loan
                program or financing, your rebate may also be affected based on interested party contribution
                guidelines. All rebates are credited to the buyer upon a successful close of escrow to your settlement
                statement and not before. Rebate program valid to 12/31/2025 or until expiration of signed buyer broker
                agreement with participating agent.
              </p>
            </div>
            <div className="text-center text-trust-gray-400">
              <p>&copy; 2024 WhyRebate. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
